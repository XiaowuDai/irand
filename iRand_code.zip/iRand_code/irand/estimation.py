import numpy as np
from joblib import Parallel, delayed
from dowhy import CausalModel
from irand.simulation import *

MAX_SEED_NB = 10000


def concatenate_dfs(df_0, df_1, seed=None):
    """
    Concatenate two DataFrames with a specified random seed for selection.

    Args:
        df_0 (pd.DataFrame): First DataFrame.
        df_1 (pd.DataFrame): Second DataFrame.
        seed (int, optional): Random seed for consistent random selection.

    Returns:
        pd.DataFrame: Concatenated DataFrame.
    """
    if seed is not None:
        np.random.seed(seed)

    # Randomly pick unique 'ID' value from either df_0 or df_1
    unique_id_mask_0 = np.random.choice([True, False], len(df_0))
    unique_id_mask_1 = ~unique_id_mask_0

    # Concatenate DataFrames
    df_concat = pd.concat([df_0.sort_values(by='ID').loc[unique_id_mask_0],
                           df_1.sort_values(by='ID').loc[unique_id_mask_1]], axis=0, ignore_index=True)

    # Sort the concatenated DataFrame by 'ID'
    df = df_concat.sort_values(by=['ID']).reset_index(drop=True)

    return df


def causal_estimate(graph, data, treatment, outcome, common_causes,
                    confidence_intervals=False, test_significance=False):
    """
    Calculate the causal estimate using propensity score matching.

    Args:
        graph (str): The graphical representation of the causal relationships.
        data (pd.DataFrame): The dataset containing the relevant variables.
        treatment (str): The name of the treatment variable.
        outcome (str): The name of the outcome variable.
        common_causes (list): List of common causes.
        confidence_intervals (bool, optional): Whether to calculate confidence intervals.
        test_significance (bool, optional): Whether to test significance.

    Returns:
        float: The causal estimate.
    """
    model = CausalModel(data=data, graph=graph.replace("\n", " "),
                        treatment=treatment, outcome=outcome, common_causes=common_causes)
    identified_estimand = model.identify_effect(method_name="exhaustive-search",
                                                proceed_when_unidentifiable=True)
    causal_estimate = model.estimate_effect(identified_estimand,
                                            method_name="backdoor.propensity_score_matching",
                                            confidence_intervals=confidence_intervals,
                                            test_significance=test_significance)
    return causal_estimate


def i_rand_single(df_0, df_1, graph, treatment, outcome, common_causes, seed=None,
                  confidence_intervals=False, test_significance=False):
    """
    Calculate the causal estimate for a single iteration of random seed.

    Args:
        df_0 (pd.DataFrame): Dataset for treatment group 0.
        df_1 (pd.DataFrame): Dataset for treatment group 1.
        graph (str): The graphical representation of the causal relationships.
        treatment (str): The name of the treatment variable.
        outcome (str): The name of the outcome variable.
        common_causes (list): List of common causes.
        seed (int, optional): Random seed for subsampling.
        confidence_intervals (bool, optional): Whether to calculate confidence intervals.
        test_significance (bool, optional): Whether to test significance.

    Returns:
        tuple: A tuple containing seed, causal estimate object, and the causal estimate value.
    """
    df_subsample = concatenate_dfs(df_0, df_1, seed)
    causal_estimate_ = causal_estimate(graph, df_subsample, treatment, outcome, common_causes,
                                       confidence_intervals, test_significance)
    return seed, causal_estimate_, causal_estimate_.value


def i_rand_parallel(df_0, df_1, graph, n_rand, root_seed, treatment, outcome, common_causes,
                    confidence_intervals=False, test_significance=False):
    """
    Calculate the average causal estimate for multiple iterations in parallel.

    Args:
        df_0 (pd.DataFrame): Dataset for treatment group 0.
        df_1 (pd.DataFrame): Dataset for treatment group 1.
        graph (str): The graphical representation of the causal relationships.
        n_rand (int): Number of random iterations.
        root_seed (int): Seed for random number generation.
        treatment (str): The name of the treatment variable.
        outcome (str): The name of the outcome variable.
        common_causes (list): List of common causes.
        confidence_intervals (bool, optional): Whether to calculate confidence intervals.
        test_significance (bool, optional): Whether to test significance.

    Returns:
        float: The average causal estimate across iterations.
    """
    np.random.seed(root_seed)
    vector_seeds = np.random.randint(0, MAX_SEED_NB, n_rand)
    results = Parallel(n_jobs=-1)(delayed(i_rand_single)(
        df_0, df_1, graph, treatment, outcome, common_causes, seed=seed,
        confidence_intervals=confidence_intervals, test_significance=test_significance
    ) for seed in vector_seeds)

    list_ate = []
    dict_causal_estimate = {}

    for i, causal_estimate_tmp, ate in results:
        dict_causal_estimate.update({i: causal_estimate_tmp})
        list_ate.append(ate)

    return np.mean(list_ate)


def i_random(df_0, df_1, graph, n_rand, root_seed, treatment, outcome, common_causes,
             confidence_intervals=False, test_significance=False):
    """
    Calculate the average causal estimate for multiple iterations.

    Args:
        df_0 (pd.DataFrame): Dataset for treatment group 0.
        df_1 (pd.DataFrame): Dataset for treatment group 1.
        graph (str): The graphical representation of the causal relationships.
        n_rand (int): Number of random iterations.
        root_seed (int): Seed for random number generation.
        treatment (str): The name of the treatment variable.
        outcome (str): The name of the outcome variable.
        common_causes (list): List of common causes.
        confidence_intervals (bool, optional): Whether to calculate confidence intervals.
        test_significance (bool, optional): Whether to test significance.

    Returns:
        float: The average causal estimate across iterations.
    """
    dict_causal_estimate = {}
    list_ate = []
    np.random.seed(root_seed)
    vector_seeds = np.random.randint(0, MAX_SEED_NB, n_rand)

    for i in range(n_rand):
        df_subsample = concatenate_dfs(df_0, df_1, vector_seeds[i])
        causal_estimate_tmp = causal_estimate(graph, df_subsample, treatment, outcome, common_causes,
                                              confidence_intervals, test_significance)
        dict_causal_estimate.update({i: causal_estimate_tmp})
        list_ate.append([causal_estimate_tmp.value])

    return np.mean(list_ate)


def causal_estimate_f(graph, data, treatment, outcome, common_causes,
                      confidence_intervals=False, test_significance=False):
    """
    Perform causal estimation using propensity score matching.

    Args:
        graph (str): Graph representation of causal relationships.
        data (pd.DataFrame): DataFrame containing the data.
        treatment (str): Treatment variable name.
        outcome (str): Outcome variable name.
        common_causes (list): List of common cause variable names.
        confidence_intervals (bool, optional): Whether to compute confidence intervals.
        test_significance (bool, optional): Whether to test for significance.

    Returns:
        CausalEstimate: Result of the causal estimation.
    """
    model = CausalModel(data=data, graph=graph.replace("\n", " "),
                        treatment=treatment, outcome=outcome, common_causes=common_causes)
    identified_estimand = model.identify_effect(method_name="exhaustive-search",
                                                proceed_when_unidentifiable=True)
    causal_estimate = model.estimate_effect(identified_estimand,
                                            method_name="backdoor.propensity_score_matching",
                                            confidence_intervals=confidence_intervals,
                                            test_significance=test_significance)
    return causal_estimate


def calculate_ATEs(dict_df, sigma_Sq, sample_size, simul_index, graph, treatment, outcome, common_causes, LCD_like=True):
    """
    Calculate Average Treatment Effects (ATEs) for different methods.

    Args:
        sigma_Sq (float): Sigma square value.
        sample_size (int): Size of the sample.
        simul_index (int): Simulation index.
        graph (str): Graph representation of causal relationships.
        treatment (str): Treatment variable name.
        outcome (str): Outcome variable name.
        common_causes (list): List of common cause variable names.

    Returns:
        tuple: ATEs calculated using different methods.
    """
    df_0 = dict_df[sigma_Sq][simul_index]['df_0'].loc[:sample_size, ]
    df_1 = dict_df[sigma_Sq][simul_index]['df_1'].loc[:sample_size, ]
    df_0['ID'] = df_1.index
    df_1['ID'] = df_1.index

    df_did = create_did(df_0, df_1, no_control=LCD_like)
    causal_estimate_did = causal_estimate_f(graph, df_did, treatment, outcome, common_causes)

    df_pooled = create_pooled(df_0, df_1)
    causal_estimate_pooled = causal_estimate_f(graph, df_pooled, treatment, outcome, common_causes)

    causal_estimate_irand = i_random(df_0, df_1, graph,
                                     1,
                                     simul_index,
                                     treatment,
                                     outcome,
                                     common_causes)

    return (sigma_Sq, sample_size, simul_index, causal_estimate_pooled,
            causal_estimate_did, causal_estimate_irand)