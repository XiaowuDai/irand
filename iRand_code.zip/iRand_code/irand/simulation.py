import os
import numpy as np
import pandas as pd
from joblib import Parallel, delayed


def DiD_data_T(df_state, outcome, treatment, common_causes):
    """
    Generate the DiD (Difference-in-Differences) data transformation.

    Args:
        df_state (pd.DataFrame): State DataFrame.
        outcome (str): Outcome variable name.
        treatment (str): Treatment variable name.
        common_causes (list): List of common cause variable names.

    Returns:
        pd.DataFrame: Transformed DataFrame.
    """
    df_state_0 = df_state.loc[(df_state['T']==False)].set_index(keys=['ID'])
    df_state_1 = df_state.loc[(df_state['T']==True)].set_index(keys=['ID'])
    df_state_diff = df_state_0.copy()
    df_state_diff0 = df_state_0.copy()
    for var in common_causes:
        df_state_diff['D' + var] = df_state_1[var].astype(float) - df_state_0[var].astype(float)
        df_state_diff0['D' + var] = df_state_diff['D' + var]
    for var in [treatment] + [outcome]:
        df_state_diff['D' + var] = df_state_1[var].astype(float) - df_state_0[var].astype(float)
        #df_state_diff[var] = df_state_1[var].astype(float) - df_state_0[var].astype(float)
        df_state_diff0['D' + var] = 0

    df_state_diff.loc[:, 'D' + treatment] = df_state_diff.loc[:, 'D' + treatment].astype(bool)
    df_state_diff0.loc[:, 'D' + treatment] = df_state_diff0.loc[:, 'D' + treatment].astype(bool)
    return pd.concat([df_state_diff0, df_state_diff]).reset_index()


def concatenate_dfs(df_0, df_1, seed=None):
    """
    Concatenate two DataFrames with random seed for selection.

    Args:
        df_0 (pd.DataFrame): First DataFrame.
        df_1 (pd.DataFrame): Second DataFrame.
        seed (int, optional): Random seed.

    Returns:
        pd.DataFrame: Concatenated DataFrame.
    """
    if seed is not None:
        np.random.seed(seed)

    # Randomly pick unique 'ID' value from either df_0 or df_1
    unique_id_mask_0 = np.random.choice([True, False], len(df_0))

    unique_id_mask_1 = ~unique_id_mask_0

    # Concatenate DataFrames
    df_concat = pd.concat([df_0.sort_values(by='ID').loc[unique_id_mask_0],
                           df_1.sort_values(by='ID').loc[unique_id_mask_1]], axis=0, ignore_index=True)

    df = df_concat.sort_values(by=['ID']).reset_index(drop=True)

    return df


def logistic_function(x, threshold=0.5):
    """
    Logistic function used for probability transformation.

    Args:
        x: Input value.
        threshold (float, optional): Threshold for the function.

    Returns:
        float: Transformed value.
    """
    return 1 / (1 + np.exp(-x + threshold))


def generate_vectors(N, rho, beta_t, sigma_square, z_variance, seed=None, threshold=0.5,
                     LCD_like=True, hidden_=True):
    """
    Generate vectors for simulation.

    Args:
        N (int): Number of samples.
        rho (float): Rho parameter.
        beta_t (list): List of beta coefficients for treatment.
        sigma_square (float): Sigma square value.
        z_variance (float): Variance for Z.
        seed (int, optional): Random seed.
        threshold (float, optional): Threshold for logistic function.
        LCD_like (bool, optional): Whether to generate like LCD variables.
        hidden_ (bool, optional): Whether to include hidden confounder.

    Returns:
        tuple: Generated DataFrames.
    """
    if seed is not None:
        np.random.seed(seed)

    t = 0
    X0_0 = np.random.normal(40, 10, N)
    X1_0 = np.random.randint(0, 2, N)

    # Generating epsilon_0 and epsilon_1 vectors with normal distribution (mean=0, variance=sigma_square)
    epsilon_0 = np.random.normal(0, np.sqrt(sigma_square), N)
    epsilon_1 = np.random.normal(0, np.sqrt(sigma_square), N)

    t = 1
    time_ = np.random.randint(1, 24, N)
    X0_1 = time_ / 12 + rho * X0_0 + np.sqrt(1 - rho ** 2) * np.random.normal(0, 1)
    X1_1 = X1_0.copy()

    # Generating t_0 and t_1 variables
    t_0 = np.zeros(N)
    t_1 = np.ones(N)

    # Hidden confounder
    # Generating Z_0 and Z_1 vectors with normal distribution (mean depends on t_0 and t_1, variance=z_variance)
    rho_Z = 0.9

    Z_0 = np.random.randint(0, 2, N)
    Z_1 = (Z_0 + np.random.randint(0, 2, N)) % 2

    # Generate random variable for T
    eps_T0 = np.random.normal(0, np.sqrt(z_variance), N)
    eps_T1 = np.random.normal(0, np.sqrt(z_variance), N)

    if LCD_like == True:
        T_0 = t_0
        T_1 = t_1
    else:
        T_0 = np.random.binomial(1, logistic_function(
            beta_t[0] * X0_0 + beta_t[1] * X1_0 + beta_t[2] * Z_0 + t_0 + eps_T0,
            threshold))
        T_1 = np.random.binomial(1, logistic_function(
            beta_t[0] * X0_1 + beta_t[1] * X1_1 + beta_t[2] * Z_1 + t_1 + eps_T1,
            threshold))

    # Create DataFrames
    df_0 = pd.DataFrame({'ID': range(N), 't': t_0, 'Z': Z_0, 'T': T_0,
                         'X0': X0_0, 'X1': X1_0, 'eps': epsilon_0})
    df_1 = pd.DataFrame({'ID': range(N), 't': t_1, 'Z': Z_1, 'T': T_1,
                         'X0': X0_1, 'X1': X1_1, 'eps': epsilon_1})

    return df_0, df_1


def generate_2p_data(N, rho, beta_t, sigma_square, z_variance, threshold,
                     alpha_, delta_, beta_, zeta_, seed,
                     LCD_like=True, hidden_=False):
    """
    Generate 2-period data.

    Args:
        N (int): Number of samples.
        rho (float): Rho parameter.
        beta_t (list): List of beta coefficients for treatment.
        sigma_square (float): Sigma square value.
        z_variance (float): Variance for Z.
        threshold (float): Threshold for logistic function.
        alpha_ (float): Alpha coefficient.
        delta_ (float): Delta coefficient.
        beta_ (list): List of beta coefficients.
        zeta_ (float): Zeta coefficient.
        seed (int): Random seed.
        LCD_like (bool, optional): Whether to generate like LCD variables.
        hidden_ (bool, optional): Whether to include hidden confounder.

    Returns:
        tuple: Generated DataFrames.
    """

    df_0, df_1 = generate_vectors(N, rho, beta_t, sigma_square, z_variance, seed, threshold,
                                  LCD_like=LCD_like, hidden_=False)

    df_0['Y'] = alpha_ + delta_ * df_0['T'] + beta_[0] * df_0['X0'
    ] + beta_[1] * df_0['X1'
                ] + beta_[2] * df_0['Z'] + df_0['eps']
    df_1['Y'] = alpha_ + delta_ * df_1['T'] + beta_[0] * df_1['X0'
    ] + beta_[1] * df_0['X1'
                ] + beta_[2] * df_1['Z'] + df_1['eps']

    df_0['T'] = df_0['T'].astype(bool)
    df_1['T'] = df_1['T'].astype(bool)

    df_0['sigma'] = np.sqrt(sigma_square)
    df_1['sigma'] = np.sqrt(sigma_square)

    df_0['seed'] = seed
    df_1['seed'] = seed

    return (seed, df_0[['T', 'X0', 'X1', 'Y', 'Z']], df_1[['T', 'X0', 'X1', 'Y',
                                                     'Z']])

def create_pooled(df_0, df_1):
    return pd.concat([df_0, df_1], ignore_index=True)


def create_did(df_0, df_1, no_control=False):
    """
    Create Difference-in-Differences (DiD) DataFrame.

    Args:
        df_0 (pd.DataFrame): First DataFrame.
        df_1 (pd.DataFrame): Second DataFrame.
        no_control (bool, optional): Whether to exclude control variables.

    Returns:
        pd.DataFrame: DiD DataFrame.
    """
    if no_control:
        df_did = DiD_data_T(pd.concat([df_0, df_1], ignore_index=True),
                            'Y',
                            'T',
                            ['X0', 'X1']
                            )[['DX0', 'DX1', 'DT', 'DY']
        ].rename(columns={'DX0': 'X0', 'DX1': 'X1', 'DT': 'T', 'DY': 'Y'})
    else:
        df_did = df_1.set_index(keys=['ID']).astype(float) - df_0.set_index(keys=['ID']).astype(float)
        df_did = df_did.reset_index()
        df_did = df_did.loc[df_did['T'] >= 0]
        df_did['T'] = df_did['T'].astype(bool)

    return df_did


def create_and_save_dataframe(folder_path, N, rho, beta_t, sigma_square, z_variance, threshold,
                              alpha_, delta_, beta_, zeta_, seed, LCD_like, hidden_):
    """
    Generate, save, and create DataFrames.

    Args:
        folder_path (str): Path to save DataFrames.
        N (int): Number of samples.
        rho (float): Rho parameter.
        beta_t (list): List of beta coefficients for treatment.
        sigma_square (float): Sigma square value.
        z_variance (float): Variance for Z.
        threshold (float): Threshold for logistic function.
        alpha_ (float): Alpha coefficient.
        delta_ (float): Delta coefficient.
        beta_ (list): List of beta coefficients.
        zeta_ (float): Zeta coefficient.
        seed (int): Random seed.
        LCD_like (bool, optional): Whether to generate like LCD variables.
        hidden_ (bool, optional): Whether to include hidden confounder.
    """
    (df_0, df_1) = generate_2p_data(N,
                                    rho,
                                    beta_t=beta_t,
                                    sigma_square=sigma_square,
                                    z_variance=z_variance,
                                    threshold=threshold,
                                    alpha_=alpha_,
                                    delta_=delta_,
                                    beta_=beta_,
                                    zeta_=zeta_,
                                    seed=seed,
                                    LCD_like=LCD_like,
                                    hidden_=hidden_)

    filename = f"df0_{seed}.csv"
    file_path = os.path.join(folder_path, filename)
    df_0.to_csv(file_path, index=False)

    filename = f"df1_{seed}.csv"
    file_path = os.path.join(folder_path, filename)
    df_1.to_csv(file_path, index=False)


def create_concatenated_data_sim(N, rho, beta_t, sigma_square, z_variance, threshold,
                                 alpha_, delta_, beta_, zeta_, seed_vector, LCD_like, hidden_):
    """
    Create concatenated data for simulation.

    Args:
        folder_path (str): Path to save DataFrames.
        N (int): Number of samples.
        rho (float): Rho parameter.
        beta_t (list): List of beta coefficients for treatment.
        sigma_square (float): Sigma square value.
        z_variance (float): Variance for Z.
        threshold (float): Threshold for logistic function.
        alpha_ (float): Alpha coefficient.
        delta_ (float): Delta coefficient.
        beta_ (list): List of beta coefficients.
        zeta_ (float): Zeta coefficient.
        seed_vector (list): List of random seeds.
        LCD_like (bool, optional): Whether to generate like LCD variables.
        hidden_ (bool, optional): Whether to include hidden confounder.

    Returns:
        dict: Dictionary containing generated DataFrames.
    """

    results = Parallel(n_jobs=-1)(delayed(generate_2p_data)(
        N,
        rho,
        beta_t=beta_t,
        sigma_square=sigma_square,
        z_variance=z_variance,
        threshold=threshold,
        alpha_=alpha_,
        delta_=delta_,
        beta_=beta_,
        zeta_=zeta_,
        seed=seed,
        LCD_like=LCD_like,
        hidden_=hidden_)
                                  for seed in seed_vector)

    dict_df = {}
    for i, df_0, df_1 in results:
        dict_df.update({i: {'df_0': df_0, 'df_1': df_1}})

    return dict_df

